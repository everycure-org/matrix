# Changelog

## 0.5.14
No function/method signature changes done in this version.

## 0.5.13
|    | Function Name                                     | Type     | Old Signature   | New Signature   |
|---:|:--------------------------------------------------|:---------|:----------------|:----------------|
|  0 | `refit.v1.core.columns_no_nulls.columns_no_nulls` | Addition | `NA`            | `()`            |

## 0.5.12
No function/method signature changes done in this version.

## 0.5.11
No function/method signature changes done in this version.

## 0.5.10
No function/method signature changes done in this version.

## 0.5.9
No function/method signature changes done in this version.

## 0.5.8
No function/method signature changes done in this version.

## 0.5.7
No function/method signature changes done in this version.

## 0.5.6
|    | Function Name                           | Type     | Old Signature   | New Signature   |
|---:|:----------------------------------------|:---------|:----------------|:----------------|
|  0 | `refit.v1.core.primary_key.primary_key` | Addition | `NA`            | `()`            |

## 0.5.5
No function/method signature changes done in this version.

## 0.5.4
No function/method signature changes done in this version.

## 0.5.3
No function/method signature changes done in this version.

## 0.5.2
